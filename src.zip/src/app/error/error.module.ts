import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NopagesfoundComponent } from './nopagesfound/nopagesfound.component';



@NgModule({
  declarations: [
    NopagesfoundComponent
  ],
  imports: [
    CommonModule
  ]
})
export class ErrorModule { }
